// import React from "react";

const Brands = () => {
    return (
        <div className="brands">
            <img src="" alt="" />
            <img src="" alt="" />
            <img src="" alt="" />
            <img src="" alt="" />

        </div>
    )
}

export default Brands